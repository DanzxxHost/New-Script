const fs = require('fs')

global.owner = "6283149813374" //owner number
global.botnumber = "6283149813374" //Nomor Bot
global.ownername = "Danzxx Hosting" //owner name
global.botname = "Danzxx Bot V1.0" // Bot Name
global.footer = "DanzxxHosting" //footer section
global.namaowner = "Danzxx Hosting" //nama owner
global.creator = "Danzxx Code" //Creator
global.versi = "1.0" //Version

//PAYMENT DANZXX HOSTING
global.andana = "WARIAH"
global.angopay = "Lupa"
global.nodana = "083149813374"
global.nogopay = "083149813374"

global.mess = {
ingroup: "It's not funny, this feature is only for groups💢",
admin: "not funny, only group admins use this feature💢",
owner: "Wow! You're not my owner🗣️",
premium: "you are not a premium user",
seller: "You don't have access as a seller yet",
wait: "please just wait ngab"
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})